package com.codebun.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.codebun.bean.UserBean;
import com.codebun.exception.ApplicationException;
import com.codebun.model.UserModel;
import com.codebun.util.DataUtility;
import com.codebun.util.ServletUtility;

/**
 * Servlet implementation class AddBalanceCtl
 */
@WebServlet(name = "AddBalanceCtl", urlPatterns = { "/ctl/userbalance" })
public class AddBalanceCtl extends BaseCtl {
	private static final long serialVersionUID = 1L;
	private static Logger log = Logger.getLogger(AddBalanceCtl.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddBalanceCtl() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		log.debug("AddBalanceCtl doGet method started");
		UserModel model = new UserModel();
		UserBean bean = new UserBean();
		HttpSession session = request.getSession();
		UserBean uBean = (UserBean) session.getAttribute("user");
		bean.setLogin(uBean.getLogin());
		System.out.println("login = "+bean.getLogin());
		long id = DataUtility.getLong(request.getParameter("id"));

		

			// UserBean bean;
			try {
				bean = model.findByLogin(bean.getLogin());

				ServletUtility.setBean(bean, request);

			} catch (ApplicationException e) {
				log.error(e);

				ServletUtility.handleException(e, request, response);
				return;
			}
	
		ServletUtility.forward(getView(), request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	@Override
	protected String getView() {
		// TODO Auto-generated method stub
		return ATMView.ADD_BALANCE_VIEW;
	}

}
