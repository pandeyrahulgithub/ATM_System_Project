package com.codebun.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.codebun.bean.BaseBean;
import com.codebun.bean.UserBean;
import com.codebun.exception.ApplicationException;
import com.codebun.exception.RecordNotFoundException;
import com.codebun.model.UserModel;
import com.codebun.util.DataUtility;
import com.codebun.util.DataValidator;
import com.codebun.util.PropertyReader;
import com.codebun.util.ServletUtility;







/**
 * Servlet implementation class ForgetPasswordCtl
 */
/**
 * ForgetPassword functionality Controller. Performs operation for Authentication, 
 * and Email send to Get Password
 *
 * @author Navigable Set
 * @version 1.0
 * @Copyright (c) Navigable Set
 * 
 */
@WebServlet(name = "ForgetPinCtl", urlPatterns = { "/forgetPin" })
public class ForgetPinCtl extends BaseCtl {
private static final long serialVersionUID = 1L;
	
	private static Logger log = Logger.getLogger(ForgetPinCtl.class);
       
	/**
	 * Validate input Data Entered By User
	 * 
	 * @param request
	 * @return
	 */

	@Override
	protected boolean validate(HttpServletRequest request) {
		log.debug("ForgetPinCtl validate  Method Started");

        boolean pass = true;

        String login = request.getParameter("login");

        if (DataValidator.isNull(login)) {
            request.setAttribute("login",
                    PropertyReader.getValue("error.require", "Email Id"));
            pass = false;
        } else if (!DataValidator.isEmail(login)) {
            request.setAttribute("login",
                    PropertyReader.getValue("error.email", "Login "));
            pass = false;
        }
        log.debug("ForgetPinCtl  validate Method Ended");

        return pass;
	}

	
	/**
	 * Populates bean object from request parameters
	 * 
	 * @param request
	 * @return
	 */
	@Override
	protected BaseBean populateBean(HttpServletRequest request) {
		 log.debug("ForgetPinCtl Method populatebean Started");

	        UserBean bean = new UserBean();

	        bean.setLogin(DataUtility.getString(request.getParameter("login")));

	        log.debug("ForgetPinCtl Method populatebean Ended");

	        return bean;
	}

		
	/**
	 * Contains display logic
	 */
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug("ForgetPasswordCtl Method doGet Started");

        ServletUtility.forward(getView(), request, response);
	}
	/**
	 * Contains submit logic
	 */
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug("ForgetPinCtl Method doPost Started");

        String op = DataUtility.getString(request.getParameter("operation"));

        UserBean bean = (UserBean) populateBean(request);

        // get model
        UserModel model = new UserModel();

        if (OP_GO.equalsIgnoreCase(op)) {

            try {
                model.forgetPin(bean.getLogin());
                
                ServletUtility.setSuccessMessage(
                        "Pin has been sent to your email id.", request);
            } catch (RecordNotFoundException e) {
                ServletUtility.setErrorMessage(e.getMessage(), request);
                log.error(e);
            } catch (ApplicationException e) {
                log.error(e);
                ServletUtility.handleException(e, request, response);
                return;
               
            } 
            ServletUtility.forward(getView(), request, response);
        }

        log.debug("ForgetPinCtl Method doPost Ended");
	}
	@Override
	protected String getView() {
		 return ATMView.FORGET_PIN_VIEW;
	}

}
