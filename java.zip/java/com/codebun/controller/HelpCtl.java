package com.codebun.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.codebun.bean.BaseBean;
import com.codebun.bean.HelpBean;
import com.codebun.bean.UserBean;
import com.codebun.exception.ApplicationException;
import com.codebun.exception.DuplicateRecordException;
import com.codebun.exception.RecordNotFoundException;
import com.codebun.model.HelpModel;
import com.codebun.model.UserModel;
import com.codebun.util.DataUtility;
import com.codebun.util.DataValidator;
import com.codebun.util.PropertyReader;
import com.codebun.util.ServletUtility;







/**
 * Servlet implementation class ChangePasswordCtl
 */

/**
 * 
 * @author Navigable Set
 * @version 1.0
 * @Copyright (c) Navigable Set
 * 
 */
@WebServlet(name = "HelpCtl", urlPatterns = { "/help" })
public class HelpCtl extends BaseCtl {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(HelpCtl.class);

	public static final String OP_CHANGE_MY_PROFILE = "Change My Profile";
	public static final String OP_CHANGE_MY_PIN = "Change Pin";

	/**
	 * Validates input data entered by User
	 * 
	 * @param request
	 * @return
	 */

	@Override
	protected boolean validate(HttpServletRequest request) {
		log.debug("HelpCtl  validate method start");

		boolean pass = true;

		String op = request.getParameter("operation");

		
		
		if (DataValidator.isNull(request.getParameter("email"))) {
			request.setAttribute("email", PropertyReader.getValue("error.require", "Email"));
			pass = false;
		}else if (!DataValidator.isEmail(request.getParameter("email"))) {
			request.setAttribute("email", PropertyReader.getValue("error.email", "Email Id"));
			return false;
		}
		if (DataValidator.isNull(request.getParameter("mobile"))) {
			request.setAttribute("mobile", PropertyReader.getValue("error.require", "Mobile No"));
			pass = false;
		} else if (!DataValidator.isPhoneNo(request.getParameter("mobile"))) {
			request.setAttribute("mobile", PropertyReader.getValue("error.invalid", "Mobile No"));
			pass = false;
		}
		
		if (DataValidator.isNull(request.getParameter("issue"))) {
			request.setAttribute("issue", PropertyReader.getValue("error.require", "Issue"));
			pass = false;
		}
		

		log.debug("HelpCtl  validate method end");
		return pass;
	}
	/**
	 * Populates bean object from request parameters
	 * 
	 * @param request
	 * @return
	 */
	@Override
	protected BaseBean populateBean(HttpServletRequest request) {
		log.debug("HelpCtl  populateBean method start");

		HelpBean bean = new HelpBean();
		bean.setEmailId(DataUtility.getString(request.getParameter("email")));
		bean.setMobileNo(DataUtility.getString(request.getParameter("mobile")));
		bean.setMessage(DataUtility.getString(request.getParameter("issue")));
	
		populateDTO(bean, request);
		log.debug("HelpCtl  populateBean method end");
		return bean;
	}

	/**
	 * Display Logics inside this method
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		log.debug("ChangePasswordCtl  doGet method start");
		ServletUtility.forward(getView(), request, response);
		log.debug("ChangePasswordCtl  doGet method end");
	}

	/**
	 * Submit logic inside it
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		log.debug("HelpCtl  doPost method start");

		

		String op = DataUtility.getString(request.getParameter("operation"));
		// get model
		HelpModel model = new HelpModel();
		if (OP_SAVE.equalsIgnoreCase(op)) {
		HelpBean bean = (HelpBean) populateBean(request);
		try {
			long pk = model.add(bean);
			bean.setId(pk);
			ServletUtility.setSuccessMessage("Issue is send successfully", request);
			ServletUtility.forward(ATMView.HELP_VIEW, request, response);
			return;
		} catch (DuplicateRecordException e) {
			
			
			ServletUtility.forward(getView(), request, response);
		} catch (ApplicationException e) {
			ServletUtility.handleException(e, request, response);
			e.printStackTrace();
			return;
		}
	} else if (OP_RESET.equalsIgnoreCase(op)) {
		ServletUtility.redirect(ATMView.HELP_CTL, request, response);
		return;
	}
		log.debug("ChangePasswordCtl  doPost method end");
}


	/**
	 * Returns the VIEW page of this Controller
	 * 
	 * @return
	 */
	@Override
	protected String getView() {
		// TODO Auto-generated method stub
		return ATMView.HELP_VIEW;
	}

}
