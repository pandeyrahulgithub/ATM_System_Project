package com.codebun.controller;

public interface ATMView {

	public String APP_CONTEXT = "/ATM-Management";

	public String PAGE_FOLDER = "/jsp";

	public String ERROR_VIEW = PAGE_FOLDER + "/Error.jsp";
	
	public String ERROR_CTL = "/ctl/ErrorCtl";
	
	public String WELCOME_VIEW = PAGE_FOLDER + "/Welcome.jsp";	
	public String WELCOME_CTL = APP_CONTEXT + "/welcome";
	
	public String LOGIN_VIEW = PAGE_FOLDER + "/LoginView.jsp";
	public String LOGOUT_CTL = APP_CONTEXT + "/LoginCtl";
	public String LOGIN_CTL = APP_CONTEXT + "/login";
	
	public String USER_REGISTRATION_CTL = APP_CONTEXT + "/register";
	public String USER_REGISTRATION_VIEW = PAGE_FOLDER + "/RegistrationView.jsp";
	
	public String USER_VIEW = PAGE_FOLDER + "/UserView.jsp";	
	public String USER_LIST_VIEW = PAGE_FOLDER + "/UserListView.jsp";
	public String USER_CTL = APP_CONTEXT + "/ctl/user";
	public String USER_LIST_CTL = APP_CONTEXT + "/ctl/userList";
	
	public String ADD_BALANCE_CTL = APP_CONTEXT + "/ctl/userbalance";
	public String ADD_BALANCE_VIEW = PAGE_FOLDER + "/AddBalanceView.jsp";
	
	public String DEPOSIT_MONEY_CTL = APP_CONTEXT + "/ctl/deposit";
	public String DEPOSIT_MONEY_VIEW = PAGE_FOLDER + "/DepositView.jsp";
	
	public String WITHDRAW_MONEY_CTL = APP_CONTEXT + "/ctl/withdraw";
	public String WITHDRAW_MONEY_VIEW = PAGE_FOLDER + "/WithdrawView.jsp";
	
	public String MINI_STATEMENT_LIST_CTL = APP_CONTEXT + "/ctl/ministatements";
	public String MINI_STATEMENT_CTL = APP_CONTEXT + "/ctl/ministatement";
	public String MINI_STATEMENT_VIEW = PAGE_FOLDER + "/MiniStatementView.jsp";
	public String MINI_STATEMENT_LIST_VIEW = PAGE_FOLDER + "/MiniStatementListView.jsp";
	
	public String CHANGE_PIN_VIEW = PAGE_FOLDER + "/ChangePinView.jsp";
	public String MY_PROFILE_VIEW = PAGE_FOLDER + "/MyProfileView.jsp";
	public String FORGET_PIN_VIEW = PAGE_FOLDER + "/ForgetPinView.jsp";
	
	public String CHANGE_PIN_CTL = APP_CONTEXT + "/ctl/changePin";
	public String MY_PROFILE_CTL = APP_CONTEXT + "/ctl/myProfile";
	public String FORGET_PIN_CTL = APP_CONTEXT + "/forgetPin";
	
	public String HELP_CTL = APP_CONTEXT + "/help";
	public String HELP_VIEW = PAGE_FOLDER + "/HelpView.jsp";
	public String HELP_LIST_CTL = APP_CONTEXT + "/ctl/issuefaced";
	public String HELP_LIST_VIEW = PAGE_FOLDER + "/HelpListView.jsp";
}
