package com.codebun.controller;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.codebun.bean.BaseBean;
import com.codebun.bean.TransactionBean;
import com.codebun.bean.UserBean;
import com.codebun.exception.ApplicationException;
import com.codebun.exception.DuplicateRecordException;
import com.codebun.model.TransactionModel;
import com.codebun.model.UserModel;
import com.codebun.util.DataUtility;
import com.codebun.util.DataValidator;
import com.codebun.util.PropertyReader;
import com.codebun.util.ServletUtility;

/**
 * Servlet implementation class WithdrawMoneyCtl
 */
@WebServlet(name = "WithdrawMoneyCtl", urlPatterns = {"/ctl/withdraw"})
public class WithdrawMoneyCtl extends BaseCtl {
	private static final long serialVersionUID = 1L;
	private static Logger log = Logger.getLogger(WithdrawMoneyCtl.class);     
    /**
     * @see HttpServlet#HttpServlet()
     */
    public WithdrawMoneyCtl() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    protected boolean validate(HttpServletRequest request) {
    	// TODO Auto-generated method stub
    	log.debug("WithdrawMoneyCtl Method validate Started");

		boolean pass = true;
		long bal = DataUtility.getLong(request.getParameter("balance"));
		if(bal < 0) {
			request.setAttribute("balance", PropertyReader.getValue("error.negative", "Amount"));
			pass = false;
		}else if (!DataValidator.isLong(request.getParameter("balance"))) {
			request.setAttribute("balance", PropertyReader.getValue("error.invalid", "Amount"));
			pass = false;
		}
		return pass;
    }
    @Override
    protected BaseBean populateBean(HttpServletRequest request) {
    	// TODO Auto-generated method stub
    	log.debug("WithdrawMoneyCtl Method populatebean Started");
		UserBean bean = new UserBean();
		bean.setId(DataUtility.getLong(request.getParameter("id")));
		bean.setAccountNo(DataUtility.getString(request.getParameter("accountNo")));
		bean.setLogin(DataUtility.getString(request.getParameter("login")));
		bean.setBalance(DataUtility.getLong(request.getParameter("balance")));
		populateDTO(bean, request);
		return bean;
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		log.debug("WithdrawMoneyCtl doGet started");
		ServletUtility.forward(getView(), request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("in post method");
		log.debug("WithdrawMoneyCtl doPost method Started");
		String op = DataUtility.getString(request.getParameter("operation"));
		// get model
		UserModel model = new UserModel();
		// get transaction model
		TransactionModel transactionModel = new TransactionModel();
		

		if (OP_WITHDRAW.equalsIgnoreCase(op)) {
			long bal = DataUtility.getLong(request.getParameter("balance"));
			UserBean bean = (UserBean) populateBean(request);
			TransactionBean transactionBean = new TransactionBean();
			HttpSession session=request.getSession();
	        UserBean uBean=(UserBean)session.getAttribute("user");
	        bean.setLogin(uBean.getLogin());
	        bean.setAccountNo(uBean.getAccountNo());
	        bean.setMobileNo(uBean.getMobileNo());
	        bean.setBalance(bal);
	        bean.setFirstName(uBean.getFirstName());
	        
	        //add bal and session bal
	        Long totalAmount = uBean.getBalance()- bal ;
	        //setting transaction
			transactionBean.setAccountNo(bean.getAccountNo());
			transactionBean.setAccountHolderName(bean.getFirstName());
			transactionBean.setMobileNo(bean.getMobileNo());
			transactionBean.setAmount(bal);
			transactionBean.setTotalAmount(totalAmount);
			transactionBean.setCreatedBy(bean.getLogin());
			transactionBean.setModifiedBy(bean.getLogin());
			transactionBean.setCreatedDatetime(new Timestamp(new Date().getTime()));
			//transactionBean.setModifiedDatetime(DataUtility.getCurrentTimestamp());
			transactionBean.setTransactionType("Withdraw");
			try {
				// System.out.println("in try sign up");
				if(bal > uBean.getBalance()) {
					ServletUtility.setErrorMessage("Insufficient Balance ", request);
					ServletUtility.forward(getView(), request, response);
					return;
				}
				model.WithdrawMoney(bean);
				transactionModel.add(transactionBean);
				// System.out.println("register");
				request.getSession().setAttribute("UserBean", bean);
				ServletUtility.setSuccessMessage("Money withdrawn Successfully", request);
				ServletUtility.forward(ATMView.WITHDRAW_MONEY_VIEW, request, response);
				return;
			} catch (DuplicateRecordException e) {
				log.error(e);
				ServletUtility.setBean(bean, request);
				ServletUtility.setErrorMessage("Login id already exists", request);
				ServletUtility.forward(getView(), request, response);
			} catch (ApplicationException e) {
				ServletUtility.handleException(e, request, response);
				e.printStackTrace();
				return;
			}
		} else if (OP_RESET.equalsIgnoreCase(op)) {
			ServletUtility.redirect(ATMView.WITHDRAW_MONEY_CTL, request, response);
			return;
		}
		log.debug("WithdrawMoneyCtl Method doPost Ended");
	}

	@Override
	protected String getView() {
		// TODO Auto-generated method stub
		return ATMView.WITHDRAW_MONEY_VIEW;
	}

}
