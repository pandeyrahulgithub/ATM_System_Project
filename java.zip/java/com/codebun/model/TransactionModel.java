package com.codebun.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.codebun.bean.TransactionBean;
import com.codebun.bean.UserBean;
import com.codebun.exception.ApplicationException;
import com.codebun.exception.DatabaseException;
import com.codebun.exception.DuplicateRecordException;
import com.codebun.util.JDBCDataSource;

public class TransactionModel{

	private static Logger log = Logger.getLogger(TransactionModel.class);
	public Integer nextPK() throws DatabaseException {
		log.debug("Model nextPK Started");
		Connection conn = null;
		int pk = 0;

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(ID) FROM TRANSACTION");
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				pk = rs.getInt(1);
			}
			rs.close();

		} catch (Exception e) {
			log.error("Database Exception..", e);
			throw new DatabaseException("Exception : Exception in getting PK");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("Model nextPK End");
		return pk + 1;
	}
	
public long add(TransactionBean bean) throws ApplicationException, DuplicateRecordException {
		
		Connection conn = null;
		int pk = 0;
		System.out.println("get = "+bean.getCreatedDatetime()+"amount "+bean.getAccountHolderName()+bean.getTotalAmount());
		try {
			conn = JDBCDataSource.getConnection();
			pk = nextPK();
			// Get auto-generated next primary key
			System.out.println(pk + " in ModelJDBC");
			conn.setAutoCommit(false); // Begin transaction
			PreparedStatement pstmt = conn.prepareStatement("INSERT INTO TRANSACTION(ID,ACCOUNTNO,NAME,MOBILENO,AMOUNT,TOTALAMOUNT,CREATEDBY,CREATEDDATETIME,MODIFIEDBY,TRANSACTIONTYPE) VALUES(?,?,?,?,?,?,?,?,?,?)");
			pstmt.setInt(1, pk);
			pstmt.setString(2, bean.getAccountNo());
			pstmt.setString(3, bean.getAccountHolderName());
			pstmt.setString(4, bean.getMobileNo());
			pstmt.setLong(5, bean.getAmount());
			pstmt.setLong(6, bean.getTotalAmount());
			pstmt.setString(7, bean.getCreatedBy());
			pstmt.setTimestamp(8, bean.getCreatedDatetime());
			pstmt.setString(9, bean.getModifiedBy());			
			//pstmt.setTimestamp(10, bean.getModifiedDatetime());	
			pstmt.setString(10, bean.getTransactionType());	
			pstmt.executeUpdate();
			conn.commit(); // End transaction
			pstmt.close();
		} catch (Exception e) {
		
			try {
				conn.rollback();
			} catch (Exception ex) {
				ex.printStackTrace();
				System.out.println(ex.getStackTrace());
				throw new ApplicationException("Exception : add rollback exception " + ex.getMessage());
			}
			throw new ApplicationException("Exception : Exception in add User "+e.getMessage());
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		
		return pk;
	}

public List search(TransactionBean bean) throws ApplicationException {
	return search(bean, 0, 0);
}

/**
 * Search Transaction with pagination
 * 
 * @return list : List of Transaction
 * @param bean
 *            : Search Parameters
 * @param pageNo
 *            : Current Page No.
 * @param pageSize
 *            : Size of Page
 * 
 * @throws DatabaseException
 */

public List search(TransactionBean bean, int pageNo, int pageSize) throws ApplicationException {
	log.debug("Model search Started");
	StringBuffer sql = new StringBuffer("SELECT * FROM TRANSACTION WHERE 1=1");

	if (bean != null) {
		if (bean.getId() > 0) {
			sql.append(" AND id = " + bean.getId());
		}
		if (bean.getTransactionType() != null && bean.getTransactionType().length() > 0) {
			sql.append(" AND TRANSACTIONTYPE like '" + bean.getTransactionType() + "%'");
		}
		/*
		 * if (bean.getLogin() != null && bean.getLogin().length() > 0) {
		 * sql.append(" AND LOGIN like '" + bean.getLogin() + "%'"); }
		 */
//		if (bean.getPin() != null && bean.getPassword().length() > 0) {
//			sql.append(" AND PASSWORD like '" + bean.getPassword() + "%'");
//		}
		
		if (bean.getCreatedDatetime() != null ) {
			sql.append(" AND CREATEDDATETIME = " + bean.getMobileNo());
		}
		
		
		

	}

	// if page size is greater than zero then apply pagination
	if (pageSize > 0) {
		// Calculate start record index
		pageNo = (pageNo - 1) * pageSize;

		sql.append(" Limit " + pageNo + ", " + pageSize);
		// sql.append(" limit " + pageNo + "," + pageSize);
	}

	System.out.println("user model search  :"+sql);
	ArrayList list = new ArrayList();
	Connection conn = null;
	try {
		conn = JDBCDataSource.getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sql.toString());
		ResultSet rs = pstmt.executeQuery();
		while (rs.next()) {
			bean = new TransactionBean();
			bean.setId(rs.getLong(1));
			bean.setAccountNo(rs.getString(2));
			bean.setAccountHolderName(rs.getString(3));
			bean.setMobileNo(rs.getString(4));
			bean.setAmount(rs.getLong(5));
			bean.setTotalAmount(rs.getLong(6));
			bean.setCreatedBy(rs.getString(7));
			bean.setModifiedBy(rs.getString(8));
			bean.setCreatedDatetime(rs.getTimestamp(9));
			bean.setModifiedDatetime(rs.getTimestamp(10));
			bean.setTransactionType(rs.getString(11));
			list.add(bean);
		}
		rs.close();
	} catch (Exception e) {
		log.error("Database Exception..", e);
		throw new ApplicationException("Exception : Exception in search user "+e.getMessage());
	} finally {
		JDBCDataSource.closeConnection(conn);
	}

	log.debug("Model search End");
	return list;
}

public List searchByUser(TransactionBean bean) throws ApplicationException {
	return search(bean, 0, 0);
}

/**
 * Search Transaction with pagination
 * 
 * @return list : List of Transaction By a user
 * @param bean
 *            : Search Parameters
 * @param pageNo
 *            : Current Page No.
 * @param pageSize
 *            : Size of Page
 * 
 * @throws DatabaseException
 */

public List searchByUser(TransactionBean bean, int pageNo, int pageSize) throws ApplicationException {
	log.debug("Model search Started");
	String createdBy = bean.getCreatedBy();
	StringBuffer sql = new StringBuffer("SELECT * FROM TRANSACTION WHERE CREATEDBY = ?");

	if (bean != null) {
		if (bean.getId() > 0) {
			sql.append(" AND id = " + bean.getId());
		}
		if (bean.getTransactionType() != null && bean.getTransactionType().length() > 0) {
			sql.append(" AND TRANSACTIONTYPE like '" + bean.getTransactionType() + "%'");
		}
		/*
		 * if (bean.getLogin() != null && bean.getLogin().length() > 0) {
		 * sql.append(" AND LOGIN like '" + bean.getLogin() + "%'"); }
		 */
//		if (bean.getPin() != null && bean.getPassword().length() > 0) {
//			sql.append(" AND PASSWORD like '" + bean.getPassword() + "%'");
//		}
		
		if (bean.getCreatedDatetime() != null ) {
			sql.append(" AND CREATEDDATETIME = " + bean.getMobileNo());
		}
		
		
		

	}

	// if page size is greater than zero then apply pagination
	if (pageSize > 0) {
		// Calculate start record index
		pageNo = (pageNo - 1) * pageSize;

		sql.append(" Limit " + pageNo + ", " + pageSize);
		// sql.append(" limit " + pageNo + "," + pageSize);
	}

	System.out.println("user model search  :"+sql);
	ArrayList list = new ArrayList();
	Connection conn = null;
	try {
		conn = JDBCDataSource.getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sql.toString());
		pstmt.setString(1, createdBy);
		ResultSet rs = pstmt.executeQuery();
		while (rs.next()) {
			bean = new TransactionBean();
			bean.setId(rs.getLong(1));
			bean.setAccountNo(rs.getString(2));
			bean.setAccountHolderName(rs.getString(3));
			bean.setMobileNo(rs.getString(4));
			bean.setAmount(rs.getLong(5));
			bean.setTotalAmount(rs.getLong(6));
			bean.setCreatedBy(rs.getString(7));
			bean.setModifiedBy(rs.getString(8));
			bean.setCreatedDatetime(rs.getTimestamp(9));
			bean.setModifiedDatetime(rs.getTimestamp(10));
			bean.setTransactionType(rs.getString(11));
			list.add(bean);
		}
		rs.close();
	} catch (Exception e) {
		log.error("Database Exception..", e);
		throw new ApplicationException("Exception : Exception in search user "+e.getMessage());
	} finally {
		JDBCDataSource.closeConnection(conn);
	}

	log.debug("Model search End");
	return list;
}
/**
 * Get List of Transaction
 * 
 * @return list : List of Transaction
 * @throws DatabaseException
 */

public List list() throws ApplicationException {
	return list(0, 0);
}

/**
 * Get List of User with pagination
 * 
 * @return list : List of users
 * @param pageNo
 *            : Current Page No.
 * @param pageSize
 *            : Size of Page
 * @throws DatabaseException
 */

public List list(int pageNo, int pageSize) throws ApplicationException {
	log.debug("Model list Started");
	ArrayList list = new ArrayList();
	StringBuffer sql = new StringBuffer("select * from TRANSACTION");
	// if page size is greater than zero then apply pagination
	if (pageSize > 0) {
		// Calculate start record index
		pageNo = (pageNo - 1) * pageSize;
		sql.append(" limit " + pageNo + "," + pageSize);
	}

	
	System.out.println("sql in list user :"+sql);
	Connection conn = null;

	try {
		conn = JDBCDataSource.getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sql.toString());
		ResultSet rs = pstmt.executeQuery();
		while (rs.next()) {
			TransactionBean bean = new TransactionBean();
			bean.setId(rs.getLong(1));
			bean.setAccountNo(rs.getString(2));
			bean.setAccountHolderName(rs.getString(3));
			bean.setMobileNo(rs.getString(4));
			bean.setAmount(rs.getLong(5));
			bean.setTotalAmount(rs.getLong(6));
			bean.setCreatedBy(rs.getString(7));
			bean.setCreatedDatetime(rs.getTimestamp(8));
			bean.setModifiedBy(rs.getString(9));				
			bean.setModifiedDatetime(rs.getTimestamp(10));
			bean.setTransactionType(rs.getString(11));
			list.add(bean);
		}
		rs.close();
	} catch (Exception e) {
		log.error("Database Exception..", e);
		throw new ApplicationException("Exception : Exception in getting list of users");
	} finally {
		JDBCDataSource.closeConnection(conn);
	}

	log.debug("Model list End");
	return list;

}

}
